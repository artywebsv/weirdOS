## Security

Please refer to [DevExpress Security Policy](https://github.com/DevExpress/Shared/security/policy)
