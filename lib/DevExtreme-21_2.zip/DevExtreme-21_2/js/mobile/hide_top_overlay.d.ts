/**
 * @docid
 * @publicName hideTopOverlay()
 * @return Boolean
 * @module mobile/hide_top_overlay
 * @namespace DevExpress
 * @export default
 * @public
 */
export default function hideTopOverlay(): boolean;
