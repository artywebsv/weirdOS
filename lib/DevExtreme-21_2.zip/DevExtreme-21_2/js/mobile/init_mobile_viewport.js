import { initMobileViewport } from './init_mobile_viewport/init_mobile_viewport';
export default initMobileViewport;
