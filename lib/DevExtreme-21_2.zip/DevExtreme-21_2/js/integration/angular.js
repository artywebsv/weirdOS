import './jquery';
import './angular/component_registrator';
import './angular/event_registrator';
import './angular/components';
import './angular/action_executors';
