import { applyChanges } from './array_utils';

export default applyChanges;
