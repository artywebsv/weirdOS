import { LoadOptions as BaseLoadOptions } from './index';

/** @deprecated */
export interface LoadOptions extends BaseLoadOptions { }
