import './modules/parts/widgets-web';
