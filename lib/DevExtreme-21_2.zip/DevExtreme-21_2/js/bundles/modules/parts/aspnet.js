/// BUNDLER_PARTS
/* Utilities for integration with ASP.NET */
/* DevExpress.aspnet = require("../../../aspnet"); */
/// BUNDLER_PARTS_END
