/* eslint-disable import/no-commonjs */
const ui = require('./widgets-base');

/// BUNDLER_PARTS
/* Mobile widgets (dx.module-widgets-mobile.js) */

ui.dxSlideOut = require('../../../ui/slide_out');
ui.dxSlideOutView = require('../../../ui/slide_out_view');
/// BUNDLER_PARTS_END
