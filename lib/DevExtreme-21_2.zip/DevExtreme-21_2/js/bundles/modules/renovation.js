/* global DevExpress */
/* eslint-disable import/no-commonjs */
import './core';

module.exports = DevExpress.renovation = {};
