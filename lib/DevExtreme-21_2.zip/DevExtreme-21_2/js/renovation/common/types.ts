// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type AbstractFunction = (...args: any) => any;
