import { presets } from './presets/presets';

export default presets;
