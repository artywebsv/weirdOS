import { TemplateBase } from './template_base';

export class ChildDefaultTemplate extends TemplateBase {
    constructor(name) {
        super();
        this.name = name;
    }
}
