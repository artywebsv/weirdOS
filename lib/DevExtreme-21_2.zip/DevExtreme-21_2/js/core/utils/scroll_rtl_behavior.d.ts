declare const getScrollRtlBehavior: () => {
  decreasing: boolean;
  positive: boolean;
};

export default getScrollRtlBehavior;
