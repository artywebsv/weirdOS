export function getPathParts(name: string): string[];
