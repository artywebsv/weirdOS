import rendererBase from './renderer_base';
export default rendererBase.get();
