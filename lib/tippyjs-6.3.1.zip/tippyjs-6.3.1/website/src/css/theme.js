export default {
  border: 'rgba(0, 32, 128, 0.12)',
  gradient: 'linear-gradient(135deg, #00acff, #6f99fc) no-repeat',
};
