# elFinder.themes

<a href="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Main-view-icons.png" target="_blank"><img src="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Main-view-icons.png" width="44%"/></a>
<a href="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Main-view-list.png" target="_blank"><img src="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Main-view-list.png" width="44%"/></a>

<a href="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Contextmenu.png" target="_blank"><img src="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Contextmenu.png" width="44%"/></a>
<a href="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Dialogs-notify.png" target="_blank"><img src="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Dialogs-notify.png" width="44%"/></a>

<a href="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Dialogs.png" target="_blank"><img src="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Dialogs.png" width="44%"/></a>
<a href="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Dialogs_2.png" target="_blank"><img src="https://github.com/johnfort/elFinder.themes/raw/master/Screenshorts/Dialogs_2.png" width="44%"/></a>
